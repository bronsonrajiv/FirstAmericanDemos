export default class LoginModal {
    public Username: string;
    public Password: string;
    public RememberMe = false;
}
