import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { QueueComponent } from './queue/queue.component';


const appRoutes: Routes = [
  {// default route
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  { path: 'login', component: LoginComponent },
  { path: 'queue', component: QueueComponent },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  // view classes: components, directives, and pipes.
  declarations: [
    AppComponent,
    LoginComponent,
    QueueComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  // global collection of services; they are accessible in all parts of the app.
  providers: [],
  // the main application view, called the root component, that hosts all other app views.
  bootstrap: [AppComponent]
})
export class AppModule { }
