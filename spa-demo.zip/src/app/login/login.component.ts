import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

import LoginModal from '../../modal/login.modal';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginModal = new LoginModal();
  isSubmitted = false;
  constructor(private router: Router) {
  }

  ngOnInit() {
  }

  onLoginClick(isFormValid: boolean) {
    this.isSubmitted = true;
    if (isFormValid) {
      this.router.navigate(['/queue']);
    }
  }
}
