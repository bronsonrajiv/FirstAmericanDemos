import { Component } from '@angular/core';
import { DataService } from '../data.service';


@Component({
  selector: 'app-queue',
  templateUrl: './queue.component.html',
  styleUrls: ['./queue.component.css'],
  providers: [DataService]
})
export class QueueComponent {
  employeeData: any;

  constructor(public service: DataService) {
    // this.employeeData = this.service.getData();

    this.service.getDataAsync().then((dataFrom) => {
      this.employeeData = dataFrom;
    }).catch((err) => {
      console.log(err);
    });
  }


}
