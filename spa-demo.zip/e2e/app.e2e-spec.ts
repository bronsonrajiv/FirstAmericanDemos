import { SpaAmpPage } from './app.po';

describe('spa-amp App', () => {
  let page: SpaAmpPage;

  beforeEach(() => {
    page = new SpaAmpPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
